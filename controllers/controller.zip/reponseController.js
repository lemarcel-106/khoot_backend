const reponseService = require('../services/reponseService');

exports.getAllReponses = async (req, res) => {
    try {
        const reponses = await reponseService.getAllReponses();
        res.status(200).json({
            success: true,
            message: 'Liste des reponses récupérée avec succès',
            data: reponses
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: 'Erreur du serveur',
            error: err.message
        });
    }
};

exports.createReponse = async (req, res) => {
    try {
        const reponse = await reponseService.createReponse(req.body);
        res.status(201).json({
            success: true,
            message: 'Reponse créé avec succès',
            data: reponse
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la création de la reponse',
            error: err.message
        });
    }
};

exports.deleteReponseById = async (req, res) => {
    try {
        const reponseId = req.body.id;
        console.log(reponseId)
        await reponseService.deleteReponseById(reponseId);
        res.status(200).json({
            success: true,
            message: 'Réponse supprimée avec succès',
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la suppression de la réponse',
            error: err.message
        });
    }
};

exports.updateReponse = async (req, res) => {
    try {
        const reponseId = req.params.id;
        const reponseData = req.body;
        const updatedReponse = await reponseService.updateReponse(reponseId, reponseData);
        res.status(200).json({
            success: true,
            message: 'Réponse mise à jour avec succès',
            data: updatedReponse
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la mise à jour de la réponse',
            error: err.message
        });
    }
}