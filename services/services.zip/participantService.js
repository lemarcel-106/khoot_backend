const Participation = require('../models/Participant');
const Planification = require('../models/Planification');

const ParticipationService = {

    createParticipation: async (participationData) => {
        try {
            const { apprenant, planification } = participationData;

            // Création de la participation
            const newParticipation = new Participation(participationData);
            const savedParticipation = await newParticipation.save();

            // Ajout de l'apprenant à la planification
            await ParticipationService.addApprenantToPlanification(savedParticipation_id, planification);

            return savedParticipation;
        } catch (error) {
            if (error.code === 11000) {
                const field = Object.keys(error.keyValue)[0];
                throw new Error(`Le champ '${field}' existe déjà.`);
            } else {
                throw new Error('Erreur lors de la création du participant : ' + error.message);
            }
        }
    },

    addApprenantToPlanification: async (apprenantId, planificationId) => {
        // Récupérer la planification par ID
        const planification = await Planification.findById(planificationId);
        if (!planification) {
            throw new Error('Planification non trouvée');
        }

        // Vérifie si l'apprenant est déjà dans la planification
        if (planification.participants.includes(apprenantId)) {
            throw new Error('L’apprenant est déjà ajouté à la planification');
        }

        // Ajouter l'ID de l'apprenant au tableau `apprenants` de la planification
        planification.participants.push(apprenantId);
        await planification.save();

        return planification;
    },

    async getAllParticipations() {
        try {
            return await Participation.find().populate('apprenant');
        } catch (error) {
            throw new Error('Erreur lors de la récupération des participations : ' + error.message);
        }
    },

    async getParticipationById(participationId) {
        try {
            return await Participation.findById(participationId).populate('apprenant');
        } catch (error) {
            throw new Error('Erreur lors de la récupération de la participation : ' + error.message);
        }
    },

    async getParticipationsByApprenant(apprenantId) {
        try {
            return await Participation.find({ apprenant: apprenantId }).populate('apprenant').populate('planification');
        } catch (error) {
            throw new Error('Erreur lors de la récupération des participations par apprenant : ' + error.message);
        }
    },

    async updateParticipant(participantId, participantData) {
        try {
            console.log(participantData, participantId)
            const updatedParticipant = await Participation.findByIdAndUpdate(
                participantId,
                { $set: participantData },
                { new: true, runValidators: true }
            );
            if (!updatedParticipant) {
                throw new Error("Participant non trouvé");
            }
            return updatedParticipant;
        } catch (error) {
            throw new Error("Erreur lors de la mise à jour du participant : " + error.message);
        }
    },

    async deleteParticipantById(participantId) {
        try {
            const deletedParticipant = await Participation.findByIdAndDelete(participantId);
            if (!deletedParticipant) {
                throw new Error("Participant non trouvé");
            }
            return deletedParticipant;
        } catch (error) {
            throw new Error("Erreur lors de la suppression du participant : " + error.message);
        }
    },

    async getParticipantsByPlanification(planificationId) {
        try {
            return await Participation.find({ planification: planificationId })
                .populate('apprenant', 'nom')
                .exec();
        } catch (error) {
            throw new Error('Erreur lors de la récupération des participants : ' + error.message);
        }
    }
};


module.exports = ParticipationService;

